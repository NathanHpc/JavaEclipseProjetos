import java.util.Scanner;

public class Ex01Tarefa {

	public static void main(String[] args) {
		
		String Nome;
		int Idade;
				
		Scanner Ler = new Scanner (System.in);
		System.out.println("Digite seu nome e depois digite sua idade");
		Nome = Ler.nextLine();
		Idade = Ler.nextInt();
		System.out.println("Nome: " + Nome);
		System.out.println("Idade: " + Idade);
		
		
	}
}
