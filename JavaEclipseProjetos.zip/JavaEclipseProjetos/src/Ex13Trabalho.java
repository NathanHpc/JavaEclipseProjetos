import java.util.Scanner;

public class Ex13Trabalho {

	public static void main(String[] args) {
		
		int idade;
		
		Scanner en = new Scanner (System.in);

				
		System.out.println("Seja Bem Vindo ao programa de classes eleitorais!");
		System.out.println("Digite sua idade, e o programa ir� dizer em qual classe eleitoral voc� se encontra.");
		System.out.println("\nDigite sua idade em n�meros a seguir: ");
		
		idade = en.nextInt();		
			
		if (idade < 1) {
			System.out.println("Voc� n�o digitou uma idade v�lida!");
	    } else if (idade < 16) {
			System.out.println("Voc� � menor de idade! Voc� � um N�o Eleitor!");
		} else if (idade >= 18 && idade < 66 ) {
			System.out.println("Voc� � um Eleitor Obrigat�rio!");
		} else {
			System.out.println("Voc� � um Eleitor Facultativo, pode ou n�o votar.");
		}
	}

}
