import java.util.Scanner;

public class Ex11Trabalho {

	public static void main(String[] args) {
		
		String sexo;
		float altura;
		
		Scanner en = new Scanner (System.in);
		
		System.out.println("Bem Vindo ao programa de peso ideal, digite a seguir seu sexo e altura \ne em seguida o programa ir� dizer seu peso ideal.\n");
		System.out.println("Digite seu sexo com 'M' de Masculino ou 'F' de Feminino a seguir: ");
		
		sexo = en.nextLine ();
		
		System.out.println("Agora digite sua altura em cm, 'ex: 1,65' a seguir: ");
		
		altura = en.nextFloat ();
		
		if (sexo.equalsIgnoreCase ("M")) {
			
			System.out.printf("Seu peso ideal �: " + "%.2f",(altura * 72.7) -58 );
		} else if (sexo.equalsIgnoreCase ("F")) {
			
			System.out.printf("Seu peso ideal �: " + "%.2f",(altura * 62.1) -44.7 );
		} else {
			System.out.println("Digito Inv�lido");
			
		}
		

	}

}
