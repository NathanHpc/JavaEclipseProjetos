import java.util.Scanner;

/*Fa�a um algoritmo de calculadora que receba dois n�meros e pe�a que o 
usu�rio entre com o sinal da opera��o que deseja fazer, entre as 
seguintes:
+, -, /, *
Realize a1 opera��o entre os dois n�meros e imprima na tela:
<numero> <operador> <numero2> = <resultado>*/

public class Ex09Ex10Trabalho {

	public static void main(String[] args) {
		
		Scanner en = new Scanner (System.in);
		float n1,n2;
		float resultado;
		char sinal;
		
		System.out.println("Bem Vindo ao programa de calculadora virtual!");
		System.out.println("Digite dois n�meros a seguir junto ao seu sinal e a calculadora lhe dar� o resultado.");
		System.out.println("Pode se usar sinais como: \"+\", \"-\", \"/\", \"*\". ");
		System.out.println("Digite o primeiro n�mero a seguir: ");
		
		n1 = en.nextFloat();
		
		System.out.println("Digite agora o segundo n�mero a seguir: ");
		
		n2 = en.nextFloat();
		
		System.out.println("Agora digite um dos sinais listados para somar, subtrair, dividir ou multiplicar os dois n�meros que digitou: ");
		
		sinal = en.next().charAt(0);
		
		if (sinal == '+') {
			System.out.println(resultado = n1 + n2);
		} else if (sinal == '-') {
			System.out.println(resultado = n1 - n2);
		} else if (sinal == '*') {
			System.out.println(resultado = n1 * n2);
		} else if (sinal == '/') {
	            if (n1 == 0 || n2 == 0) {
	                System.out.println("Esse n�mero n�o pode ser dividido por 0");
	            } else
	                System.out.println(resultado = n1 / n2);
	        }
	    }
}