import java.util.Scanner;

public class Ex02Tarefa {

	public static void main(String[] args) {
		
		float n1,n2;
	    String Operador;
	    String X = "+";
	    
	    n1 = 20.00f;
	    n2 = 43.00f;
	    
	    Scanner Ler = new Scanner(System.in);
	   
	    Operador = Ler.next ();
	    
	    switch (Operador) {
	    
	    case "+": 
	    	
	    	System.out.println(n1 + n2);
	    
  case "*": 
	    	
	    	System.out.println(n1 * n2);
	    

	    }

	}
}
