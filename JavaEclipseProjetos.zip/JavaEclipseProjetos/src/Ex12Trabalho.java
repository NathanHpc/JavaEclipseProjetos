import java.util.Scanner;

public class Ex12Trabalho {

	public static void main(String[] args) {
		
		Scanner en = new Scanner (System.in);
		int idade;
		
		System.out.println("A confedera��o brasileira de nata��o ir� promover eliminat�rias para o pr�ximo mundial.");
		System.out.println("Entre com sua idade e o programa ir� dizer em qual categoria de nadador voc� se encaixa.\n");
		System.out.println("Digite sua idade a seguir em n�meros: ");
		
		idade = en.nextInt();
		
		if (idade >= 5 && idade < 8) {
			System.out.println("Voce est� incluido na categoria \"Infantil A\".");			
		} else if (idade >= 8 && idade < 11 ) {
			System.out.println("Voce est� incluido na categoria \"Infantil B\".");
		} else if (idade >= 11 && idade < 14) {
			System.out.println("Voce est� incluido na categoria \"Juvenil A\".");
		} else if (idade >= 14 && idade < 18 ) {
			System.out.println("Voce est� incluido na categoria \"Juvenil B\".");
		} else if (idade >= 18 ) {
			System.out.println("Voce est� incluido na categoria \"S�nior\".");
		} else {
			System.out.println("Voc� n�o est� incluido em nenhuma das Faixas et�rias para competir.");
		}
	}

}
