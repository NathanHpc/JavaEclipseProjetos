import java.util.Scanner;

public class Ex16Trabalho {

	public static void main(String[] args) {
		
		Scanner en = new Scanner (System.in);
		
		String nome, primeiraLetra;
		float compras;
		
		System.out.println("Bem Vindo ao programa de descontos por inicial de nome,\nse o nome corresponder com uma das iniciais premiadas desta semana, receber� um desconto de 30%!");
		System.out.println("\nDigite seu nome a seguir: ");
		
		nome = en.nextLine();
		
		System.out.println("Agora digite o valor final de suas compras: ");
		
		compras = en.nextFloat();		
		primeiraLetra = nome.substring(0,1);
		
		if (primeiraLetra.toUpperCase().equals("A") || primeiraLetra.toUpperCase().equals("D") || primeiraLetra.toUpperCase().equals("M") || primeiraLetra.toUpperCase().equals("S")) {		
			compras = (float) (compras - (compras * 0.3));
			System.out.println("Parab�ns! Voc� obteve desconto, e suas compras com 30% de desconto ficaram: R$" + compras);
			
		} else {
			System.out.println("Que pena! Parece que voc� n�o conseguiu desconto desta vez. O valor final de sua compra � de: R$" + compras);
		}
		
		

	}

}
