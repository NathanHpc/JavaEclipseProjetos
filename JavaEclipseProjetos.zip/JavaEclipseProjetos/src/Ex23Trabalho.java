import java.util.Scanner;

public class Ex23Trabalho {

	public static void main(String[] args) {
		
Scanner en = new Scanner (System.in);

double imc;
float peso;
float altura;

System.out.println("Bem Vindo ao sistema de �ndice de Massa Corporal (IMC).");
System.out.println("Digite a seguir sua altura e seu peso\ne o programa dir� em que faixa de risco voc� se encontra.");
System.out.println("\nDigite a seguir sua altura em metros, ex: 1,75.");

altura = en.nextFloat();

System.out.println("A seguir digite seu peso em kg, ex: 60.");

peso = en.nextFloat();

imc = peso / (Math.pow(altura, 2));
if (imc < 20) {	
	System.out.printf("Seu IMC diz que voc� est� (Abaixo Do Peso), seu IMC �: %.2f", imc);
	
} else if (imc >= 20 && imc <= 25) {
	System.out.printf("Seu IMC diz que voc� est� com (Peso Normal), seu IMC �: %.2f", imc);
	
} else if (imc > 25 && imc <= 30) {
	System.out.printf("Seu IMC diz que voc� est� com (Excesso de peso), seu IMC �: %.2f", imc);
	
} else if (imc > 30 && imc <= 35) {
	System.out.printf("Seu IMC diz que voc� est� com (Obesidade), seu IMC �: %.2f", imc);

} else if (imc > 35) {
	System.out.printf("Seu IMC diz que voc� est� com (Obesidade M�rbida), seu IMC �: %.2f", imc);
	

	  }	
   }
}
