import java.util.Scanner;

public class Ex22Trabalho {

	public static void main(String[] args) {
		
		Scanner en = new Scanner(System.in);
		
		String produto;
		float valorc;
		double valorv;
		
		System.out.println("Bem Vindo ao sistema de lucro sobre produtos! Voc� � o comerciante e dir� quanto pagou no produto.");
		System.out.println("Sobre o valor pago no produto, o programa mostrar� quanto de lucro voc� ter� nele e dir� o valor final a ser vendido!");
		System.out.println("\nDigite o nome do produto do qual deseja atribuir valor: ");
		produto = en.nextLine();
		
		System.out.println("Digite a seguir o valor que voc� pagou no produto: ");
		
		valorc = en.nextFloat();
		
		if (valorc < 10) {
			valorv = (valorc * 0.70 + valorc);
			System.out.println("Produto " + produto + " comprado por: R$" + valorc + "\nProduto: " + produto+ ", com o lucro de 70% vendido por: R$" + valorv );
			
		} else if (valorc >= 10 && valorc < 30) {
			valorv = (valorc * 0.50 + valorc);
			System.out.println("Produto " + produto + " comprado por: R$" + valorc + "\nProduto: " + produto+ ", com o lucro de 50% vendido por: R$" + valorv );
			
		} else if (valorc >= 30 && valorc < 50) {
			valorv = (valorc * 0.40 + valorc);
			System.out.println("Produto " + produto + " comprado por: R$" + valorc + "\nProduto: " + produto+ ", com o lucro de 40% vendido por: R$" + valorv );
			
		} else if (valorc >= 50) {
			valorv = (valorc * 0.30 + valorc);
			System.out.println("Produto " + produto + " comprado por: R$" + valorc + "\nProduto: " + produto+ ", com o lucro de 30% vendido por: R$" + valorv );
		}

	}
}
